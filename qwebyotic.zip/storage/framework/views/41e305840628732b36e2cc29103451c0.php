
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('admin.posts.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded mb-4 inline-block">
    + Add New Post
</a>

<div class="bg-white shadow rounded p-4">
    <table class="w-full">
        <tr class="bg-gray-200 text-left">
            <th class="p-2">Title</th>
            <th class="p-2">Category</th>
            <th class="p-2">Created At</th>
            <th class="p-2">Action</th>
        </tr>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="p-2"><?php echo e($post->title); ?></td>
            <td class="p-2"><?php echo e($post->category->name ?? 'None'); ?></td>
            <td class="p-2"><?php echo e($post->created_at->format('d M Y')); ?></td>
            <td class="p-2">
                <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="text-blue-500">Edit</a>
                <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="text-red-500" onclick="return confirm('Delete?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <?php echo e($posts->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nproject\task7\nextjs-tailwind-app\webyotic\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>