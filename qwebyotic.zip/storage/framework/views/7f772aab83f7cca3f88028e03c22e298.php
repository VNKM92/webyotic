<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded p-4">
    <h1 class="text-2xl font-bold mb-4">Edit Post</h1>

    <form action="<?php echo e(route('admin.posts.update', $post->id)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-4">
            <label for="title" class="block text-sm font-medium text-gray-700">Title</label>
            <input type="text" name="title" id="title" value="<?php echo e($post->title); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
        </div>

        <div class="mb-4">
            <label for="category_id" class="block text-sm font-medium text-gray-700">Category</label>
            <select name="category_id" id="category_id" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                <option value="">None</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($post->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-4">
            <label for="body" class="block text-sm font-medium text-gray-700">Body</label>
            <textarea name="body" id="body" rows="10" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required><?php echo e($post->body); ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <label for="image" class="block text-sm font-medium text-gray-700">Image URL</label>
                <input type="text" name="image" id="image" value="<?php echo e($post->image); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
            </div>
            <div>
                <label for="focus_keyword" class="block text-sm font-medium text-gray-700">Focus Keyword</label>
                <input type="text" name="focus_keyword" id="focus_keyword" value="<?php echo e($post->focus_keyword); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
            </div>
        </div>

        <div class="mb-4">
            <label for="seo_title" class="block text-sm font-medium text-gray-700">SEO Title</label>
            <input type="text" name="seo_title" id="seo_title" value="<?php echo e($post->seo_title); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <div class="mb-4">
            <label for="seo_description" class="block text-sm font-medium text-gray-700">SEO Description</label>
            <textarea name="seo_description" id="seo_description" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"><?php echo e($post->seo_description); ?></textarea>
        </div>
        <div class="mb-4">
            <label for="seo_keywords" class="block text-sm font-medium text-gray-700">SEO Keywords (comma-separated)</label>
            <input type="text" name="seo_keywords" id="seo_keywords" value="<?php echo e($post->seo_keywords); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nproject\task7\nextjs-tailwind-app\webyotic\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>